package com.example.mc_assignmet_3_2

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import java.time.LocalDate



@Entity(tableName = "DATA_TABLE")
data class OriData(
    @ColumnInfo(name="timestamp") val timestmp:Long,
    @ColumnInfo(name="pitch") val pitch: Float,
    @ColumnInfo(name="roll") val roll: Float,
    @ColumnInfo(name="yaw") val yaw:Float,

    ){
    @PrimaryKey(autoGenerate = true) @ColumnInfo(name="id") var id:Int = 0
}
