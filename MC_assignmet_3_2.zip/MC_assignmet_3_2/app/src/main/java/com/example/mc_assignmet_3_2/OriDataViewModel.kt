package com.example.mc_assignmet_3_2


import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Inject


@HiltViewModel
class OriDataViewModel @Inject constructor(application: Application) : AndroidViewModel(application) {


    private val repo: OriDataRepo
    val read_all: LiveData<List<OriData>>

    init {
        val daytempDao = OriDatabase.getDatabase(application).daytempdao()
        repo = OriDataRepo(daytempDao)
        read_all = repo.readallData

    }

    fun insert_data(daytemp:OriData){
        viewModelScope.launch(Dispatchers.IO)
        {
            repo.insert(daytemp)
        }
    }

//    fun insertManyRaw(list:List<OriData>){
//        viewModelScope.launch(Dispatchers.IO)
//        {
//            repo.insertManyRow(list)
//        }
//    }

//    fun read_data(dateString:String, location:String):List<OriData>{
//        return repo.read_data(dateString, location)
//    }
//
//    fun read_data_by_mmdd(mmdd:String, location:String):List<OriData>{
//        return repo.read_data_by_mmdd(mmdd, location)
//    }




}





