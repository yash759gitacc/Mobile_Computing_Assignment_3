package com.example.mc_assignmet_3_2

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow
import java.time.LocalDate


@Dao
interface OriDataDao
{

//    @Insert(onConflict = OnConflictStrategy.REPLACE)
//    fun insertManyRaws(raws: List<OriData>): List<Long>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(oridata:OriData)

//    @Query( "SELECT * FROM DATA_TABLE WHERE date=:dateString AND location=:location" )
//    fun getData(dateString:String, location:String): List<OriData>

    @Query("SELECT * FROM DATA_TABLE")
    fun read_all(): LiveData<List<OriData>>

//    @Query("SELECT * FROM DATA_TABLE WHERE SUBSTR(date, 5, 2) || SUBSTR(date, 7, 2)=:mmdd AND location=:location")
//    fun getdatabymmdd(mmdd:String, location:String): List<OriData>

}
