package com.example.mc_assignmet_3_2

import android.content.Context
import android.content.Intent
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.mc_assignmet_3_2.ui.theme.MC_assignmet_3_2Theme
import kotlinx.coroutines.flow.MutableStateFlow
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Button
//import androidx.compose.material.Text
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
//import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import kotlin.math.atan2
//import kotlin.math

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)



        setContent {
            MC_assignmet_3_2Theme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                )
                {
                    AccelerometerOrientationApp()
                }
            }
        }
    }


    @Composable
    fun AccelerometerOrientationApp() {
        val context = LocalContext.current
        val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val gyroscope = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE) // Get gyroscope sensor

        val pitch = remember { mutableStateOf(0.0) }
        val yaw = remember { mutableStateOf(0.0) }
        val roll = remember { mutableStateOf(0.0) }

        val rotationMatrix = FloatArray(9)
        val geomagnetic = FloatArray(3)

        LaunchedEffect(gyroscope) {
            gyroscope?.let { sensor ->
                val listener = object : SensorEventListener {
                    override fun onSensorChanged(event: SensorEvent?) {
                        if (event != null) {
                            val x = event.values[0]
                            val y = event.values[1]
                            val z = event.values[2]

                            // Using a low-pass filter to filter out noise from the accelerometer
                            val alpha = 0.8f
                            val gravityFiltered = FloatArray(3)
                            gravityFiltered[0] = alpha * gravityFiltered[0] + (1 - alpha) * event.values[0]
                            gravityFiltered[1] = alpha * gravityFiltered[1] + (1 - alpha) * event.values[1]
                            gravityFiltered[2] = alpha * gravityFiltered[2] + (1 - alpha) * event.values[2]

                            val acceleration = FloatArray(3)
                            System.arraycopy(event.values, 0, acceleration, 0, event.values.size)
                            acceleration[0] = gravityFiltered[0] - acceleration[0]
                            acceleration[1] = gravityFiltered[1] - acceleration[1]
                            acceleration[2] = gravityFiltered[2] - acceleration[2]

                            pitch.value = acceleration[0].toDouble()
                            roll.value = acceleration[1].toDouble()
                            yaw.value = acceleration[2].toDouble()

//                            val accMagOrientation = FloatArray(3)
//                            SensorManager.getRotationMatrix(rotationMatrix, null, acceleration, geomagnetic)
//                            SensorManager.getOrientation(rotationMatrix, accMagOrientation)
//
//                            pitch.value = Math.toDegrees(accMagOrientation[1].toDouble())
//                            roll.value = Math.toDegrees(accMagOrientation[2].toDouble())
//                            yaw.value = Math.toDegrees(accMagOrientation[0].toDouble())

                        }
                    }

                    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
                }

                sensorManager.registerListener(
                    listener, sensor, SensorManager.SENSOR_DELAY_NORMAL
                )
            }
        }

        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "Pitch: ${pitch.value.format(2)}°",
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = "Roll: ${roll.value.format(2)}°",
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = "Yaw: ${yaw.value.format(2)}°", // Placeholder for future yaw calculation
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )

                Button(onClick = {
                    val intent = Intent(context, DatabaseActivity::class.java)
                    startActivity(intent)
                }) {
                    Text(text = "Start Database activity")
                }
            }
        }
    }

    fun Double.format(decimals: Int) = "%.${decimals}f".format(this)


}