package com.example.mc_assignmet_3_2


import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase


@Database(
    entities = [OriData::class],
    version = 1,
    exportSchema = false
)
abstract class OriDatabase: RoomDatabase() {



    abstract fun daytempdao(): OriDataDao
    companion object {

        @Volatile private var INSTANCE: OriDatabase? = null

        fun getDatabase(context: Context): OriDatabase
        {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    OriDatabase::class.java,
                    "Orientation Database"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }

}











