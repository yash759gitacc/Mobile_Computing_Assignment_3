package com.example.mc_assignmet_3_2

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModelProvider
import com.example.mc_assignmet_3_2.ui.theme.MC_assignmet_3_2Theme

class DatabaseActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MC_assignmet_3_2Theme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val viewmodel: OriDataViewModel = ViewModelProvider(this)[OriDataViewModel::class.java]
                    AccelerometerOrientationApp(viewmodel)
                }
            }
        }
    }

    fun Double.format(decimals: Int) = "%.${decimals}f".format(this)

@Composable fun AccelerometerOrientationApp(viewmodel: OriDataViewModel) {
    val context = LocalContext.current
    val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    val gyroscope = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE) // Get gyroscope sensor
    val pitch = remember { mutableStateOf(0.0) }
    val yaw = remember { mutableStateOf(0.0) }
    val roll = remember { mutableStateOf(0.0) }
    val saveInDatabase = remember { mutableStateOf(false) }
    val savingRate = remember { mutableStateOf(60) }
    val rotationMatrix = FloatArray(9)
    val geomagnetic = FloatArray(3)
    LaunchedEffect(gyroscope) {
        gyroscope?.let { sensor ->
            val listener = object : SensorEventListener {
                override fun onSensorChanged(event: SensorEvent?) {
                    if (event != null) {
                        val x = event.values[0]
                        val y = event.values[1]
                        val z = event.values[2]

                        // Using a low-pass filter to filter out noise from the accelerometer
                        val alpha = 0.8f
                        val gravityFiltered = FloatArray(3)
                        gravityFiltered[0] = alpha * gravityFiltered[0] + (1 - alpha) * event.values[0]
                        gravityFiltered[1] = alpha * gravityFiltered[1] + (1 - alpha) * event.values[1]
                        gravityFiltered[2] = alpha * gravityFiltered[2] + (1 - alpha) * event.values[2]

                        val acceleration = FloatArray(3)
                        System.arraycopy(event.values, 0, acceleration, 0, event.values.size)
                        acceleration[0] = gravityFiltered[0] - acceleration[0]
                        acceleration[1] = gravityFiltered[1] - acceleration[1]
                        acceleration[2] = gravityFiltered[2] - acceleration[2]

                        pitch.value = acceleration[0].toDouble()
                        roll.value = acceleration[1].toDouble()
                        yaw.value = acceleration[2].toDouble()

                        val timestamp = System.currentTimeMillis()
                        saveInDatabase(viewmodel , pitch.value,roll.value,yaw.value,timestamp)

//                            val accMagOrientation = FloatArray(3)
//                            SensorManager.getRotationMatrix(rotationMatrix, null, acceleration, geomagnetic)
//                            SensorManager.getOrientation(rotationMatrix, accMagOrientation)
//
//                            pitch.value = Math.toDegrees(accMagOrientation[1].toDouble())
//                            roll.value = Math.toDegrees(accMagOrientation[2].toDouble())
//                            yaw.value = Math.toDegrees(accMagOrientation[0].toDouble())

                    }
                }
                override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
            }
            sensorManager.registerListener(
                listener, sensor, savingRate.value*1000
            )
        }
    }

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = "Pitch: ${pitch.value.format(2)}°",
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
            Text(
                text = "Roll: ${roll.value.format(2)}°",
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
            Text(
                text = "Yaw: ${yaw.value.format(2)}°", // Placeholder for future yaw calculation
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )

            TextField(
                value = savingRate.value.toString(),
                onValueChange = { newText ->
                    if (newText.isEmpty() || newText.toIntOrNull() != null)
                    {
                        savingRate.value = Integer.parseInt(newText)
                    }
                },
                label = { Text("Enter an Integer") },
                keyboardOptions = KeyboardOptions.Default.copy(keyboardType = KeyboardType.Number)
            )
            Text(text = "Entered Integer: ${savingRate.value}")

            Button(onClick = {
                if (savingRate.value <= 20){
                    Toast.makeText(context , "The rate can not be less than 20", Toast.LENGTH_LONG).show()
                }
                else {
                    saveInDatabase.value = true
                    Toast.makeText(context , "Saving in database started", Toast.LENGTH_LONG).show()
                }
            }) {
                Text(text = "Start saving in database")
            }
            Spacer(modifier = Modifier)
            Button(onClick = {

            }
            ) {
                Text(text = "Show Graph")

            }

        }
    }
}


    private fun saveInDatabase(viewmodel:OriDataViewModel, pitch: Float, roll: Float, yaw: Float, timestamp: Long)
    {

        val obj = OriData(timestamp,pitch,roll,yaw)
        viewmodel.insert_data(obj)
    }

    @Composable fun AccelerometerGraph() {

        val accelerometerData = listOf(
            OriData(1000, 0.2f, 0.3f, 0.2f),
            OriData(2000, 0.3f, 0.4f, 0.4f),
            OriData(3000, 0.4f, 0.5f, 0.3f),
            OriData(4000, 0.5f, 0.6f, 0.5f),
            OriData(5000, 0.6f, 0.7f, 0.6f)
        )

        Canvas(modifier = Modifier.fillMaxSize()) {
            val canvasWidth = size.width
            val canvasHeight = size.height

            val centerX = canvasWidth / 2
            val centerY = canvasHeight / 2

            val scale = 20f // Adjust scale as needed for better visualization

            accelerometerData.forEachIndexed { index, data ->
                val x = centerX + data.roll * scale
                val y = centerY + data.pitch * scale
                val nextX = if (index < accelerometerData.size - 1) {
                    centerX + accelerometerData[index + 1].roll * scale
                } else {
                    x
                }
                val nextY = if (index < accelerometerData.size - 1) {
                    centerY + accelerometerData[index + 1].pitch * scale
                } else {
                    y
                }
                drawLine(
                    color = Color.Blue,
                    start = Offset(x.toFloat(), y.toFloat()),
                    end = Offset(nextX.toFloat(), nextY.toFloat()),
                    strokeWidth = 2.dp.toPx(),
                    cap = Stroke.DefaultCap
                )
            }
        }
    }



}