package com.example.mc_assignmet_3_2



import android.util.Log
import androidx.annotation.WorkerThread
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject


class OriDataRepo @Inject constructor (private val daytempDao: OriDataDao)  {


    val readallData =  daytempDao.read_all()

//    fun read_data(dateString:String, location:String):List<OriData> {
//        val temp: List<OriData> = daytempDao.getData(dateString , location)
//        Log.d("IN repo output size" , temp.size.toString())
//        return temp
//    }
//
//    fun read_data_by_mmdd(mmdd:String, location:String):List<OriData> {
//        val temp: List<OriData> = daytempDao.getdatabymmdd(mmdd , location)
//        return temp
//    }


    @Suppress("RedundantSuspendModifier")
    @WorkerThread
    suspend fun insert(daytemp:OriData) {
        daytempDao.insert(daytemp)
    }

//    suspend fun insertManyRow(list:List<OriData>){
//        daytempDao.insertManyRaws(list)
//    }


}